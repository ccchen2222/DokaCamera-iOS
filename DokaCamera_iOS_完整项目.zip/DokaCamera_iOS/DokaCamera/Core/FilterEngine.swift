//
//  FilterEngine.swift
//  DokaCamera
//
//  Film LUT filter engine extracted from com.ydgn.doka APK
//  Original Android implementation uses GLSL shaders + 3D LUT textures
//  iOS implementation uses Core Image CIColorCube filter
//

import UIKit
import CoreImage

/// Film filter presets matching the original Doka app
enum FilmFilter: String, CaseIterable {
    // Fujifilm series
    case fuji160C = "lut_f_160c"
    case fuji400H = "lut_f_400h"
    case fujiC200 = "lut_f_c200"
    case fujiCC = "lut_f_cc"
    case fujiClassicChrome = "lut_f_classic_chrome"
    case fujiClassicNeg = "lut_f_classic_neg"
    case fujiCN = "lut_f_cn"
    case fujiProNeg = "lut_f_pro_neg"
    case fujiProvia = "lut_f_provia"
    case fujiS100 = "lut_f_s100"
    case fujiS400 = "lut_f_s400"
    case fujiVelvia = "lut_f_velvia"
    
    // Kodak series
    case kodakGold200 = "lut_k_gold_200"
    case kodakPortra160 = "lut_k_portra_160"
    case kodakPortra400 = "lut_k_portra_400"
    
    // Agfa series
    case agfaAP100 = "lut_agfa_ap_100"
    case agfaVista800 = "lut_agfa_vista_800"
    
    // Doka custom series
    case dokaS50 = "lut_doka_s50"
    case dokaS100 = "lut_doka_s100"
    case dokaS160 = "lut_doka_s160"
    case dokaS200 = "lut_doka_s200"
    case dokaS400 = "lut_doka_s400"
    case dokaX100 = "lut_doka_x100"
    case dokaX400 = "lut_doka_x400"
    
    var displayName: String {
        switch self {
        case .fuji160C: return "Fuji 160C"
        case .fuji400H: return "Fuji 400H"
        case .fujiC200: return "Fuji C200"
        case .fujiCC: return "Fuji CC"
        case .fujiClassicChrome: return "Classic Chrome"
        case .fujiClassicNeg: return "Classic Neg"
        case .fujiCN: return "Fuji CN"
        case .fujiProNeg: return "Pro Neg"
        case .fujiProvia: return "Provia"
        case .fujiS100: return "Fuji S100"
        case .fujiS400: return "Fuji S400"
        case .fujiVelvia: return "Velvia"
        case .kodakGold200: return "Kodak Gold 200"
        case .kodakPortra160: return "Portra 160"
        case .kodakPortra400: return "Portra 400"
        case .agfaAP100: return "Agfa AP 100"
        case .agfaVista800: return "Agfa Vista 800"
        case .dokaS50: return "Doka S50"
        case .dokaS100: return "Doka S100"
        case .dokaS160: return "Doka S160"
        case .dokaS200: return "Doka S200"
        case .dokaS400: return "Doka S400"
        case .dokaX100: return "Doka X100"
        case .dokaX400: return "Doka X400"
        }
    }
}

class FilterEngine {
    static let shared = FilterEngine()
    private let context = CIContext()
    
    /// Apply film filter to image using 3D LUT
    func applyFilter(_ filter: FilmFilter, to image: UIImage) -> UIImage? {
        guard let inputImage = CIImage(image: image) else { return nil }
        guard let lutData = loadLUTData(for: filter) else { return nil }
        
        // Create CIColorCube filter with LUT data
        let colorCubeFilter = CIFilter(name: "CIColorCube")
        colorCubeFilter?.setValue(inputImage, forKey: kCIInputImageKey)
        colorCubeFilter?.setValue(64, forKey: "inputCubeDimension")
        colorCubeFilter?.setValue(lutData, forKey: "inputCubeData")
        
        guard let outputImage = colorCubeFilter?.outputImage else { return nil }
        guard let cgImage = context.createCGImage(outputImage, from: outputImage.extent) else { return nil }
        
        return UIImage(cgImage: cgImage, scale: image.scale, orientation: image.imageOrientation)
    }
    
    /// Load and convert PNG LUT to Core Image cube data
    /// Original Android implementation: 64x64x64 RGB cube stored as 512x512 PNG
    private func loadLUTData(for filter: FilmFilter) -> Data? {
        guard let lutImage = UIImage(named: filter.rawValue) else {
            print("⚠️ LUT image not found: \(filter.rawValue).png")
            return nil
        }
        
        guard let cgImage = lutImage.cgImage else { return nil }
        
        let width = cgImage.width
        let height = cgImage.height
        
        // LUT cube dimension (typically 64 for film emulation)
        let dimension = 64
        let cubeSize = dimension * dimension * dimension
        var cubeData = [Float](repeating: 0, count: cubeSize * 4) // RGBA
        
        // Read pixel data from PNG
        guard let pixelData = cgImage.dataProvider?.data,
              let data = CFDataGetBytePtr(pixelData) else { return nil }
        
        let bytesPerPixel = cgImage.bitsPerPixel / 8
        let bytesPerRow = cgImage.bytesPerRow
        
        // Convert 2D LUT texture to 3D cube data
        // Layout: horizontal strips, each strip is one Z-slice
        for z in 0..<dimension {
            for y in 0..<dimension {
                for x in 0..<dimension {
                    // Calculate 2D coordinates in source image
                    let srcX = z * dimension + x
                    let srcY = y
                    
                    guard srcX < width && srcY < height else { continue }
                    
                    let pixelIndex = srcY * bytesPerRow + srcX * bytesPerPixel
                    let r = Float(data[pixelIndex]) / 255.0
                    let g = Float(data[pixelIndex + 1]) / 255.0
                    let b = Float(data[pixelIndex + 2]) / 255.0
                    
                    // Write to cube data
                    let cubeIndex = (z * dimension * dimension + y * dimension + x) * 4
                    cubeData[cubeIndex] = r
                    cubeData[cubeIndex + 1] = g
                    cubeData[cubeIndex + 2] = b
                    cubeData[cubeIndex + 3] = 1.0
                }
            }
        }
        
        return Data(bytes: &cubeData, count: cubeData.count * MemoryLayout<Float>.size)
    }
    
    /// Preview thumbnail for filter
    func generateThumbnail(for filter: FilmFilter, sourceImage: UIImage, size: CGSize) -> UIImage? {
        guard let resized = resizeImage(sourceImage, to: size) else { return nil }
        return applyFilter(filter, to: resized)
    }
    
    private func resizeImage(_ image: UIImage, to size: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, 1.0)
        image.draw(in: CGRect(origin: .zero, size: size))
        let resized = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return resized
    }
}
