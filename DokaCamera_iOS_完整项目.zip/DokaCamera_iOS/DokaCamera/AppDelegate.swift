//
//  AppDelegate.swift
//  DokaCamera
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // Setup main window
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = CameraViewController()
        window?.makeKeyAndVisible()
        
        // Request camera permission
        AVCaptureDevice.requestAccess(for: .video) { granted in
            if !granted {
                print("⚠️ Camera permission denied")
            }
        }
        
        // Request photo library permission
        PHPhotoLibrary.requestAuthorization { status in
            if status != .authorized {
                print("⚠️ Photo library permission denied")
            }
        }
        
        return true
    }
}
