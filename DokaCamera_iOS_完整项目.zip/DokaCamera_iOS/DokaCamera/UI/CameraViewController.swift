//
//  CameraViewController.swift
//  DokaCamera
//
//  Core camera implementation using AVFoundation
//  Matches original Android CameraX functionality
//

import UIKit
import AVFoundation

class CameraViewController: UIViewController {
    
    // MARK: - Camera Session
    private let captureSession = AVCaptureSession()
    private var photoOutput = AVCapturePhotoOutput()
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private var currentFilter: FilmFilter = .fujiClassicChrome
    
    // MARK: - UI Components
    private let captureButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.backgroundColor = .white
        btn.layer.cornerRadius = 35
        btn.layer.borderWidth = 3
        btn.layer.borderColor = UIColor.systemGray.cgColor
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    private let filterCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 80, height: 100)
        layout.minimumInteritemSpacing = 8
        
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.backgroundColor = .clear
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.register(FilterCell.self, forCellWithReuseIdentifier: "FilterCell")
        return cv
    }()
    
    private let filterNameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        setupCamera()
        setupUI()
        updateFilterLabel()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            self?.captureSession.startRunning()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        captureSession.stopRunning()
    }
    
    // MARK: - Camera Setup
    
    private func setupCamera() {
        captureSession.sessionPreset = .photo
        
        // Add camera input
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: camera),
              captureSession.canAddInput(input) else {
            print("⚠️ Failed to setup camera")
            return
        }
        
        captureSession.addInput(input)
        
        // Add photo output
        if captureSession.canAddOutput(photoOutput) {
            captureSession.addOutput(photoOutput)
            photoOutput.isHighResolutionCaptureEnabled = true
        }
        
        // Setup preview layer
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer?.videoGravity = .resizeAspectFill
        previewLayer?.frame = view.bounds
        
        if let previewLayer = previewLayer {
            view.layer.insertSublayer(previewLayer, at: 0)
        }
    }
    
    private func setupUI() {
        // Capture button
        view.addSubview(captureButton)
        captureButton.addTarget(self, action: #selector(capturePhoto), for: .touchUpInside)
        
        // Filter collection
        view.addSubview(filterCollectionView)
        filterCollectionView.delegate = self
        filterCollectionView.dataSource = self
        
        // Filter name label
        view.addSubview(filterNameLabel)
        
        NSLayoutConstraint.activate([
            // Capture button (bottom center)
            captureButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            captureButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -120),
            captureButton.widthAnchor.constraint(equalToConstant: 70),
            captureButton.heightAnchor.constraint(equalToConstant: 70),
            
            // Filter collection (bottom)
            filterCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            filterCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            filterCollectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            filterCollectionView.heightAnchor.constraint(equalToConstant: 100),
            
            // Filter name (above collection)
            filterNameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            filterNameLabel.bottomAnchor.constraint(equalTo: filterCollectionView.topAnchor, constant: -12)
        ])
    }
    
    // MARK: - Actions
    
    @objc private func capturePhoto() {
        let settings = AVCapturePhotoSettings()
        settings.flashMode = .auto
        
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
    
    private func updateFilterLabel() {
        filterNameLabel.text = currentFilter.displayName
    }
}

// MARK: - AVCapturePhotoCaptureDelegate

extension CameraViewController: AVCapturePhotoCaptureDelegate {
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard error == nil,
              let imageData = photo.fileDataRepresentation(),
              let originalImage = UIImage(data: imageData) else {
            print("⚠️ Photo capture failed: \(error?.localizedDescription ?? "unknown")")
            return
        }
        
        // Apply selected filter
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            let filteredImage = FilterEngine.shared.applyFilter(self.currentFilter, to: originalImage) ?? originalImage
            
            DispatchQueue.main.async {
                self.showPreview(image: filteredImage)
            }
        }
    }
    
    private func showPreview(image: UIImage) {
        let previewVC = PhotoPreviewViewController(image: image)
        previewVC.modalPresentationStyle = .fullScreen
        present(previewVC, animated: true)
    }
}

// MARK: - UICollectionView Delegate & DataSource

extension CameraViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return FilmFilter.allCases.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FilterCell", for: indexPath) as! FilterCell
        let filter = FilmFilter.allCases[indexPath.item]
        
        cell.configure(with: filter, isSelected: filter == currentFilter)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentFilter = FilmFilter.allCases[indexPath.item]
        updateFilterLabel()
        collectionView.reloadData()
    }
}

// MARK: - Filter Cell

class FilterCell: UICollectionViewCell {
    
    private let thumbnailView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 8
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = .systemFont(ofSize: 10)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.addSubview(thumbnailView)
        contentView.addSubview(nameLabel)
        
        NSLayoutConstraint.activate([
            thumbnailView.topAnchor.constraint(equalTo: contentView.topAnchor),
            thumbnailView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            thumbnailView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            thumbnailView.heightAnchor.constraint(equalToConstant: 80),
            
            nameLabel.topAnchor.constraint(equalTo: thumbnailView.bottomAnchor, constant: 4),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    func configure(with filter: FilmFilter, isSelected: Bool) {
        nameLabel.text = filter.displayName
        
        // Create gradient thumbnail
        thumbnailView.backgroundColor = isSelected ? .systemBlue : .darkGray
        
        // TODO: Generate actual filter preview thumbnail
        // let preview = FilterEngine.shared.generateThumbnail(for: filter, sourceImage: sampleImage, size: CGSize(width: 80, height: 80))
        // thumbnailView.image = preview
        
        layer.borderWidth = isSelected ? 2 : 0
        layer.borderColor = UIColor.white.cgColor
        layer.cornerRadius = 8
    }
}

// MARK: - Photo Preview

class PhotoPreviewViewController: UIViewController {
    
    private let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    private let saveButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Save", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = .systemBlue
        btn.layer.cornerRadius = 25
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    private let closeButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("✕", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 24)
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    private let image: UIImage
    
    init(image: UIImage) {
        self.image = image
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) not implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        imageView.image = image
        
        view.addSubview(imageView)
        view.addSubview(saveButton)
        view.addSubview(closeButton)
        
        saveButton.addTarget(self, action: #selector(savePhoto), for: .touchUpInside)
        closeButton.addTarget(self, action: #selector(closePreview), for: .touchUpInside)
        
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            imageView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -40),
            saveButton.widthAnchor.constraint(equalToConstant: 120),
            saveButton.heightAnchor.constraint(equalToConstant: 50),
            
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            closeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            closeButton.widthAnchor.constraint(equalToConstant: 44),
            closeButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    @objc private func savePhoto() {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(imageSaved(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc private func imageSaved(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            print("⚠️ Save failed: \(error.localizedDescription)")
        } else {
            let alert = UIAlertController(title: "Saved", message: "Photo saved to library", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                self?.closePreview()
            })
            present(alert, animated: true)
        }
    }
    
    @objc private func closePreview() {
        dismiss(animated: true)
    }
}
