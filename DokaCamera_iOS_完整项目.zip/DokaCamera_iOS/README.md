# Doka Camera iOS - 构建指南

## 项目说明

这是从 Android APK `com.ydgn.doka` 逆向提取资源后，完全重写的 iOS 原生版本。

**核心功能**：
- ✅ 24 种胶片滤镜（Fujifilm、Kodak、Agfa、Doka 自研）
- ✅ 实时相机预览
- ✅ 滤镜预览和切换
- ✅ 照片保存到相册

**技术栈**：
- Swift 5+
- AVFoundation（相机）
- Core Image（滤镜引擎）
- UIKit（界面）

---

## 构建步骤

### 1. 安装 Xcode

确保你的 Mac 安装了 **Xcode 14.0+**：
```bash
xcode-select --install
```

### 2. 创建 Xcode 项目

1. 打开 Xcode
2. **File → New → Project**
3. 选择 **iOS → App**
4. 配置：
   - **Product Name**: `DokaCamera`
   - **Organization Identifier**: `com.yourcompany`（改成你的）
   - **Interface**: `Storyboard`
   - **Language**: `Swift`
   - **Bundle Identifier**: `com.yourcompany.DokaCamera`

### 3. 导入代码文件

将以下文件拖入 Xcode 项目：

```
DokaCamera/
├── AppDelegate.swift          ← 替换默认的
├── Core/
│   └── FilterEngine.swift     ← 滤镜引擎
├── UI/
│   └── CameraViewController.swift  ← 相机界面
└── Resources/
    └── Filters/               ← 24 个 LUT PNG 文件
        ├── lut_f_classic_chrome.png
        ├── lut_k_portra_400.png
        └── ...
```

**重要**：拖入 `Filters` 文件夹时勾选 "Copy items if needed" 和 "Create folder references"。

### 4. 配置 Info.plist

替换 `Info.plist` 为项目提供的版本，或手动添加以下权限：

```xml
<key>NSCameraUsageDescription</key>
<string>Doka needs camera access to take photos with film filters</string>

<key>NSPhotoLibraryAddUsageDescription</key>
<string>Doka needs photo library access to save your filtered photos</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>Doka needs photo library access to load and edit photos</string>
```

### 5. 修复导入语句

在 `AppDelegate.swift` 顶部添加：
```swift
import AVFoundation
import Photos
```

在 `CameraViewController.swift` 顶部确认已有：
```swift
import AVFoundation
import Photos
```

### 6. 设置 Bundle Identifier

1. 在 Xcode 中选择项目根节点
2. 选择 **TARGETS → DokaCamera**
3. **General → Identity**
4. **Bundle Identifier** 改成你的唯一 ID（例如 `com.你的名字.DokaCamera`）

### 7. 配置签名

**TARGETS → DokaCamera → Signing & Capabilities**：
- 勾选 **Automatically manage signing**
- **Team**: 选择你的 Apple ID 或开发者账号

### 8. 构建和运行

**真机测试**（推荐）：
1. 用数据线连接 iPhone
2. 在 Xcode 顶部选择你的设备
3. 点击 **▶ Run** 或按 `Cmd+R`

**模拟器测试**（相机不可用，只能测试 UI）：
1. 选择 **iPhone 14 Pro** 模拟器
2. 点击 **▶ Run**

---

## 打包 IPA（用于分发）

### 方法 1: Archive（官方）

1. **Product → Archive**
2. 等待构建完成
3. **Window → Organizer** 会自动打开
4. 选择刚才的 Archive
5. 点击 **Distribute App**
6. 选择方式：
   - **Ad Hoc**（给测试设备）
   - **Development**（开发设备）
   - **App Store**（上架 App Store）

### 方法 2: Export IPA（快速）

在 Archive 完成后：
1. **Organizer → Distribute App**
2. 选择 **Ad Hoc**
3. 勾选 **Rebuild from Bitcode**（可选）
4. 选择签名证书
5. **Export** 导出 IPA 文件

导出的 IPA 在：
```
~/Library/Developer/Xcode/Archives/...
```

### 方法 3: 命令行构建

```bash
# 清理
xcodebuild clean -project DokaCamera.xcodeproj -scheme DokaCamera

# Archive
xcodebuild archive \
  -project DokaCamera.xcodeproj \
  -scheme DokaCamera \
  -archivePath build/DokaCamera.xcarchive

# Export IPA
xcodebuild -exportArchive \
  -archivePath build/DokaCamera.xcarchive \
  -exportPath build/IPA \
  -exportOptionsPlist ExportOptions.plist
```

需要创建 `ExportOptions.plist`：
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>ad-hoc</string>
    <key>teamID</key>
    <string>YOUR_TEAM_ID</string>
</dict>
</plist>
```

---

## 安装到 iPhone

### 方法 1: Xcode 直接安装
- 用数据线连接 iPhone
- Xcode 中点击 **▶ Run**

### 方法 2: 用 IPA 安装（无需 Xcode）

**工具选择**：
1. **AltStore**（免费，需要电脑）
2. **Sideloadly**（免费）
3. **Apple Configurator**（Mac 官方工具）
4. **TestFlight**（需要开发者账号）

**用 Sideloadly 安装**：
1. 下载 [Sideloadly](https://sideloadly.io/)
2. 连接 iPhone
3. 拖入 IPA 文件
4. 输入 Apple ID
5. 点击 **Start**

**用 TestFlight 分发**（推荐给测试用户）：
1. 需要付费 Apple Developer 账号（$99/年）
2. 在 App Store Connect 创建应用
3. 上传 IPA
4. 邀请测试用户通过 TestFlight 安装

---

## 常见问题

### Q: "Team is required to sign..."
**A**: 在 **Signing & Capabilities** 中选择你的 Apple ID 或开发者账号。

### Q: "No devices registered"
**A**: 真机测试需要在 Xcode 中先信任设备。连接后在 **Window → Devices and Simulators** 中点击 "Use for Development"。

### Q: 滤镜不生效
**A**: 检查 `Resources/Filters/` 中的 24 个 PNG 文件是否正确导入。在 Xcode 左侧文件树中应该能看到蓝色文件夹图标。

### Q: 相机黑屏
**A**: 检查 `Info.plist` 中是否添加了 `NSCameraUsageDescription`。真机上检查 **设置 → DokaCamera → 相机** 是否授权。

### Q: 照片保存失败
**A**: 检查 `NSPhotoLibraryAddUsageDescription` 权限，并在 **设置 → DokaCamera → 照片** 中授权。

### Q: 构建报错 "Could not find module"
**A**: 检查所有 Swift 文件是否正确导入到项目中。在文件上右键 → **Show File Inspector**，确认 **Target Membership** 勾选了 `DokaCamera`。

---

## 下一步优化

当前版本是 **MVP（最小可行产品）**，可以继续添加：

1. **更多功能**：
   - 视频录制 + 实时滤镜
   - 照片编辑（裁剪、调整参数）
   - 自定义滤镜强度

2. **UI 优化**：
   - 滤镜缩略图预览（当前是占位色块）
   - 动画和转场效果
   - 暗黑模式适配

3. **性能优化**：
   - Metal 加速滤镜渲染
   - 异步加载 LUT 数据
   - 内存优化

4. **社交功能**：
   - 分享到社交媒体
   - 云端滤镜库
   - 用户账号系统

---

## 项目结构

```
DokaCamera_iOS/
├── DokaCamera/
│   ├── AppDelegate.swift              # 应用入口
│   ├── Info.plist                     # 配置文件
│   ├── Core/
│   │   └── FilterEngine.swift         # 滤镜引擎（LUT 加载和应用）
│   ├── UI/
│   │   └── CameraViewController.swift # 相机界面 + 预览
│   └── Resources/
│       └── Filters/                   # 24 个 LUT PNG 文件
│           ├── lut_f_classic_chrome.png
│           ├── lut_k_portra_400.png
│           └── ...
├── Podfile                            # CocoaPods 依赖（可选）
└── README.md                          # 本文件
```

---

## 技术细节

### LUT 滤镜原理

原 Android 版本使用 GLSL 着色器 + 3D LUT 纹理：
```glsl
// fragment_shader_lut_es2.glsl
vec3 color = texture2D(inputTexture, vTexCoord).rgb;
vec3 lutColor = texture3D(lutTexture, color).rgb;
```

iOS 版本用 Core Image 的 `CIColorCube`：
```swift
let filter = CIFilter(name: "CIColorCube")
filter?.setValue(64, forKey: "inputCubeDimension")
filter?.setValue(lutData, forKey: "inputCubeData")
```

LUT 数据格式：
- **维度**: 64×64×64 RGB 立方体
- **存储**: 512×512 PNG（横向排列，每 64 列是一个 Z 切片）
- **大小**: 每个 LUT 约 200-300 KB

### 相机流程

1. **初始化**: `AVCaptureSession` + `AVCaptureDevice`
2. **预览**: `AVCaptureVideoPreviewLayer`
3. **拍照**: `AVCapturePhotoOutput.capturePhoto()`
4. **应用滤镜**: `FilterEngine.applyFilter()`
5. **保存**: `UIImageWriteToSavedPhotosAlbum()`

---

## License

本项目从 Android APK 逆向提取资源用于学习研究。
原应用版权归 com.ydgn.doka 所有。
请勿用于商业用途。

---

**生成时间**: 2026-10-03
**来源**: com.ydgn.doka.apk (v1.3.12)
**工具**: 寒霜破甲执行器
